# Brickbound Hero — Training & Orc animation pack

Mở `preview_training_orc.html` bằng trình duyệt để xem. File đã nhúng ảnh, không cần Internet. Giữ file ZIP cạnh HTML nếu muốn dùng nút tải ZIP trên trang.

Trong ZIP:

- `assets/tiles/training/`: bốn màu, bảy animation/màu.
- `assets/tiles/orc_shield/`: bốn Orc, chín nét mặt/Orc, mười hai animation/màu.
- `assets/fx/tile_reactions/`: bụi, va chạm, vụn gỗ, confetti.
- `assets/tiles/animation_pack.json`: rect, tốc độ, thời lượng, loop và tên sự kiện.
- `sprite_frames_<color>.tres` trong từng bộ: kéo vào AnimatedSprite2D trong Godot 4.7.2.
- `docs/ideas/asset_preview/index.html`: bản xem dùng file ảnh ngoài, cùng JavaScript và công cụ xuất lại.
- `docs/ideas/animation_pack.md`: hướng dẫn tích hợp và phạm vi.

Sprite thường 128×128; sheet animation có 24 frame 192×192 (kèm vùng đệm FX), xếp 8 cột × 3 hàng. Có 76 sheet chuyển động và 8 bộ SpriteFrames. Thắng/thua tính theo người chơi. Frame kết thúc Orc chết phải giữ trong suốt; không tự quay về idle.

Bộ này là asset, dữ liệu animation và trang xem thử; chưa tích hợp vào logic game. Không có giọng cười/hét thu âm. Chi tiết biểu cảm có sai khác nhỏ giữa frame vì đây là chuỗi sprite, chưa phải rig nhân vật.

Các file `.import` được Godot sinh lại khi đưa asset vào project; ZIP không chứa cache `.godot/`.
